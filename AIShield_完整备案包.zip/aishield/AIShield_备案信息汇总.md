# AIShield 项目备案信息汇总

**生成时间**: 2026-07-18
**项目名称**: AIShield（AI安全盾）
**项目定位**: Agent可信生态的安全基础设施

---

## 1. 项目概述

- **全称**: AIShield - AI Agent Security Platform
- **中文**: AI安全盾
- **Slogan**: 让每个Agent都可信
- **GitHub**: github.com/lm203688/aishield (待创建公开仓库)
- **域名**: aishield.tools (待注册)
- **临时URL**: http://150.158.119.19:8420

## 2. 服务器与部署

### ECS服务器
- **IP**: 150.158.119.19 (腾讯云)
- **SSH**: ubuntu@150.158.119.19
- **服务端口**:
  - 8420: AIShield主API服务 (Python Flask)
  - 8450: AIShield合规工具服务 (gunicorn + Flask)
  - 3003: 小乌AI副手 (OpenAI兼容API)
  - 80/443: Nginx反代

### 部署通道
- **代码仓库**: 本地 → GitHub (lm203688/aishield) → ECS pull_and_restart
- **部署API**: POST http://150.158.119.19:8420/api/v1/deploy
- **部署Token**: atex_deploy_2026
- **ECS代码路径**: /home/ubuntu/atex/

### Cloudflare
- **账户**: 463102527@qq.com
- **CF API Token**: cfut_j3cJdlzdFbPI2DdVodTncAJuNI8CvgcV6p5D3dXU8cf6b00b
- **Cloudflare Tunnel**: aishield.tools → localhost:8420
- **注意**: 腾讯云未备案域名在80/443被拦截，需通过CF Tunnel或8420端口访问

## 3. API密钥与认证

### AIShield API Key (Eve体验金)
- **Key**: atex_sk_8004cd6fb4ac389e261d11d4d8e01294676018fedb67f557
- **额度**: ¥5体验金

### 部署Token
- **Token**: atex_deploy_2026

### GitHub
- **用户名**: lm203688
- **PAT**: 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

### Creem支付
- **商店**: FrontierKB (sto_7gBcCekvUKTpsaAFyf)
- **API Key**: creem_4yM8aDDK17QiHjWdiWgQEA
- **6个产品**: Daily Brief $19/月, Intelligence Pro $49/月, API Access $29/月, Lifetime $99, Full DB $499, Single Domain $49

### 小乌AI副手
- **Base URL**: http://150.158.119.19:3003/v1
- **Key**: xiaowu-internal-2026
- **模型**: xiaowu-agent

## 4. 服务架构 (23个服务)

### 合规服务 (4个)
1. 违禁词检测 ¥0.5/次
2. 出海合规评估 ¥50/次
3. SEO合规检测 ¥3/次
4. AI搜索可见度 ¥5/次

### AI能力服务 (12个)
- 6个AI模型调用 (GPT/Claude/Gemini/DeepSeek/Qwen/智谱)
- 知识库搜索/实体详情
- 翻译/摘要/代码生成

### 知识蒸馏 (2个)
- GeneTech 14站知识库
- AIShield安全知识库

### 基础设施 (2个)
- 文件存储
- IndexNow SEO提交

### 自动化 (1个)
- 定时任务调度

### 安全 (2个)
- MCP安全扫描 ¥10/次 (21个工具已扫描)
- Prompt注入检测 (30+规则)

## 5. AIShield合规工具 (8450端口)

### 数据
- **MCP工具扫描**: 21个工具已扫描
- **审计记录**: 135条
- **违禁词库**: 6大平台(微信/抖音/小红书/B站/知乎/微博)
- **Prompt检测规则**: 30+条(中英文双语)

### API端点 (8450)
- GET /api/v1/health - 健康检查
- POST /api/v1/audit - 合规审计
- GET /api/v1/stats - 统计数据
- GET /api/v1/tools - 工具列表
- GET /api/v1/pricing - 定价
- POST /api/v1/prompt-check - Prompt检测

### 启动命令
```bash
cd /home/z/my-project/aishield && \
PYTHONPATH=/home/z/my-project/aishield/aishield \
/home/z/.venv/bin/gunicorn api.server_flask:app \
--bind 0.0.0.0:8450 --workers 2 --timeout 30 --threads 2 --daemon --pid aishield/aishield.pid
```

## 6. MCP Server

- **端点**: http://150.158.119.19:8420/mcp
- **工具**: aishield_scan, aishield_guardrail, aishield_prompt_check
- **包名**: @aishield/mcp-server (待npm发布)
- **AI Plugin**: http://150.158.119.19:8420/.well-known/ai-plugin.json
- **OpenAPI**: http://150.158.119.19:8420/api/v1/openapi.json

## 7. GEO资产 (2026-07-18补全)

| 文件 | 路径 | 用途 |
|------|------|------|
| llms.txt | /llms.txt | AI Agent简明指南 |
| llms-full.txt | /llms-full.txt | AI Agent详细指南 |
| ai-plugin.json | /ai-plugin.json + /.well-known/ | OpenAI插件标准 |
| openapi.json | /openapi.json | API规范 |
| schema.json | /schema.json | Schema.org结构化数据 |
| agent-discovery.json | /agent-discovery.json | Agent发现层 |
| manifest.json | /manifest.json | PWA清单 |
| robots.txt | /robots.txt | 爬虫规则 |
| sitemap.xml | /sitemap.xml | 站点地图 |

## 8. 三阶段发展规划

### Phase 1: 合规安全切入 (2026Q3, 0-3个月)
- 目标: 产生现金流，积累用户和安全数据
- 目标收入: 月收入≥¥3000
- 产品: 违禁词检测、MCP安全扫描、出海合规

### Phase 2: Agent可信工具市场 (2026Q4, 3-6个月)
- 目标: 建立Agent安全信任壁垒
- 关键动作: MCP安全评分+认证标签

### Phase 3: Agent经济闭环 (2027Q1-Q2, 6-12个月)
- 目标: 成为Agent生态安全层+支付层

## 9. 竞品定位

| 竞品 | 定位 | AIShield差异 |
|------|------|-------------|
| Smithery | MCP目录 | AIShield做安全背书 |
| Glama | MCP目录 | AIShield做安全背书 |
| LangChain | AI框架 | 互补而非竞争 |

## 10. 代码结构

```
/home/z/my-project/aishield/
├── aishield/              # 合规工具子服务(8450)
│   ├── api/               # Flask API
│   ├── data/              # 违禁词库+扫描结果
│   ├── scanner/           # 安全扫描器
│   ├── mcp/               # MCP Server
│   └── templates_v2/      # Web界面
├── server/                # 主API服务(8420)
│   ├── api/               # 主API
│   ├── services/          # 23个服务
│   ├── payment/           # 支付网关
│   └── data/              # 配置
├── mcp/                   # MCP Server (TypeScript)
├── config/                # 项目配置
├── marketing/             # 营销材料
├── scripts/               # 部署脚本
├── web/                   # 前端
├── CHARTER.md             # 项目纲领
├── README.md              # 项目说明
├── llms.txt               # GEO资产
├── ai-plugin.json         # GEO资产
├── openapi.json           # GEO资产
└── ...
```

## 11. 关键文件清单

### 核心代码
- server/api/server.py - 主API服务
- aishield/api/server_flask.py - 合规服务
- aishield/scanner/advanced_audit.py - 高级安全审计
- aishield/scanner/rules_v3.py - 扫描规则
- mcp/src/index.ts - MCP Server

### 配置
- config/project.json - 项目配置
- server/config.json - 服务配置
- server/services/services.json - 23个服务定义

### 数据
- aishield/data/tools.json - 21个MCP工具扫描结果
- aishield/data/audits.json - 135条审计记录
- aishield/data/api_keys.json - API Key管理

### 营销
- marketing/strategy/ai-native-distribution.md - AI原生分发战略
- CHARTER.md - 项目纲领

## 12. 联系方式
- **邮箱**: 61960005@qq.com
- **GitHub**: lm203688

---

**注意**: 本文档包含所有敏感信息（API密钥、服务器密码、部署Token等），请妥善保管，不要泄露给未授权人员。
