"""
AgentTrust Protocol — 信任评分引擎
从TypeScript移植到Python，合并到AIShield
4维评分：完成率35% + 可靠性30% + 一致性20% + 响应速度15%
"""

import math
from datetime import datetime, timezone
from typing import List, Dict, Optional
from dataclasses import dataclass, field


@dataclass
class TransactionRecord:
    """Agent交易记录"""
    tx_id: str
    agent_did: str          # Agent去中心化标识
    service: str             # 服务名称
    status: str              # success / failed / disputed
    response_ms: int = 0     # 响应时间(毫秒)
    created_at: str = ""     # ISO时间
    amount: float = 0        # 交易金额
    metadata: Dict = field(default_factory=dict)


@dataclass
class TrustScore:
    """信任评分结果"""
    agent_did: str
    composite_score: float       # 0-100综合分
    completion_rate: float       # 完成率
    reliability_score: float     # 可靠性
    consistency_score: float     # 一致性(EWMA)
    response_time_score: float   # 响应速度
    grade: str                   # A+/A/B+/B/C+/C/D/F
    confidence: str              # high/medium/low/insufficient
    transaction_count: int
    calculated_at: str


class TrustScorer:
    """信任评分引擎"""

    # 评分权重（必须和为1.0）
    WEIGHTS = {
        "completion_rate": 0.35,
        "reliability_score": 0.30,
        "consistency_score": 0.20,
        "response_time": 0.15,
    }

    # 最低交易数门槛
    MIN_LOW = 5
    MIN_MEDIUM = 25
    MIN_HIGH = 100

    # 响应时间基准
    FAST_MS = 500
    SLOW_MS = 10_000

    # EWMA半衰期
    HALF_LIFE_MS = 30 * 24 * 60 * 60 * 1000  # 30天

    def score(self, agent_did: str, records: List[TransactionRecord]) -> TrustScore:
        """计算Agent信任评分"""
        if not records:
            return TrustScore(
                agent_did=agent_did, composite_score=0,
                completion_rate=0, reliability_score=0, consistency_score=0,
                response_time_score=0, grade="F", confidence="insufficient",
                transaction_count=0, calculated_at=datetime.now(timezone.utc).isoformat()
            )

        # 1. 完成率
        success_count = sum(1 for r in records if r.status == "success")
        completion_rate = (success_count / len(records)) * 100

        # 2. 可靠性（成功-争议比）
        disputed = sum(1 for r in records if r.status == "disputed")
        failed = sum(1 for r in records if r.status == "failed")
        reliability_score = max(0, 100 - (disputed * 20 + failed * 10))

        # 3. 一致性（EWMA时间衰减）
        consistency_score = self._ewma_consistency(records)

        # 4. 响应速度
        response_times = [r.response_ms for r in records if r.response_ms > 0]
        if response_times:
            avg_ms = sum(response_times) / len(response_times)
            response_time_score = self._normalise_response_time(avg_ms)
        else:
            response_time_score = 70  # 默认值

        # 综合分
        composite = (
            completion_rate * self.WEIGHTS["completion_rate"] +
            reliability_score * self.WEIGHTS["reliability_score"] +
            consistency_score * self.WEIGHTS["consistency_score"] +
            response_time_score * self.WEIGHTS["response_time"]
        )

        # 等级
        grade = self._grade(composite)

        # 置信度
        confidence = self._confidence(len(records))

        return TrustScore(
            agent_did=agent_did, composite_score=round(composite, 1),
            completion_rate=round(completion_rate, 1),
            reliability_score=round(reliability_score, 1),
            consistency_score=round(consistency_score, 1),
            response_time_score=round(response_time_score, 1),
            grade=grade, confidence=confidence,
            transaction_count=len(records),
            calculated_at=datetime.now(timezone.utc).isoformat()
        )

    def _ewma_consistency(self, records: List[TransactionRecord]) -> float:
        """EWMA指数加权移动平均（30天半衰期）"""
        if not records:
            return 70  # 贝叶斯先验

        decay = math.log(2) / self.HALF_LIFE_MS
        now = datetime.now(timezone.utc)

        # 先验：10笔伪交易，30天前，分值70
        prior_weight = 10 * math.exp(-decay * self.HALF_LIFE_MS)  # ~5
        weighted_sum = prior_weight * 70
        total_weight = prior_weight

        for r in records:
            try:
                tx_time = datetime.fromisoformat(r.created_at.replace("Z", "+00:00"))
                age_ms = max(0, (now - tx_time).total_seconds() * 1000)
            except:
                age_ms = self.HALF_LIFE_MS

            weight = math.exp(-decay * age_ms)
            value = 100 if r.status == "success" else (0 if r.status == "disputed" else 30)
            weighted_sum += weight * value
            total_weight += weight

        return round(weighted_sum / total_weight)

    def _normalise_response_time(self, avg_ms: float) -> float:
        """归一化响应时间到0-100"""
        if avg_ms <= self.FAST_MS:
            return 100
        if avg_ms >= self.SLOW_MS:
            return 0
        return round(100 * (1 - (avg_ms - self.FAST_MS) / (self.SLOW_MS - self.FAST_MS)))

    def _grade(self, score: float) -> str:
        """评分转等级"""
        if score >= 95: return "A+"
        if score >= 85: return "A"
        if score >= 75: return "B+"
        if score >= 65: return "B"
        if score >= 55: return "C+"
        if score >= 45: return "C"
        if score >= 30: return "D"
        return "F"

    def _confidence(self, count: int) -> str:
        """置信度"""
        if count >= self.MIN_HIGH: return "high"
        if count >= self.MIN_MEDIUM: return "medium"
        if count >= self.MIN_LOW: return "low"
        return "insufficient"

    def to_w3c_vc(self, score: TrustScore) -> Dict:
        """转换为W3C可验证凭证格式"""
        return {
            "@context": ["https://www.w3.org/2018/credentials/v1"],
            "type": ["VerifiableCredential", "AgentTrustScore"],
            "issuer": "did:web:aishield.tools",
            "issuanceDate": score.calculated_at,
            "credentialSubject": {
                "id": score.agent_did,
                "trustScore": score.composite_score,
                "grade": score.grade,
                "confidence": score.confidence,
                "dimensions": {
                    "completionRate": score.completion_rate,
                    "reliability": score.reliability_score,
                    "consistency": score.consistency_score,
                    "responseTime": score.response_time_score,
                },
                "transactionCount": score.transaction_count,
                "weights": self.WEIGHTS,
            }
        }
