"""
AIShield信任评分API
将AgentTrust Protocol集成为AIShield的信任评分服务
"""

from flask import Flask, request, jsonify
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from scoring import TrustScorer, TransactionRecord

app = Flask(__name__)
scorer = TrustScorer()

# 简单内存存储（后续可换PostgreSQL）
transactions_db = {}


@app.route("/api/v1/trust/score/<did>", methods=["GET"])
def get_score(did):
    """获取Agent信任评分"""
    records = transactions_db.get(did, [])
    if not records:
        return jsonify({
            "did": did,
            "message": "No transactions found. Submit transactions to get a trust score.",
            "composite_score": 0,
            "grade": "N/A",
            "confidence": "insufficient"
        })
    score = scorer.score(did, records)
    return jsonify({
        "did": score.agent_did,
        "composite_score": score.composite_score,
        "grade": score.grade,
        "confidence": score.confidence,
        "transaction_count": score.transaction_count,
        "dimensions": {
            "completion_rate": score.completion_rate,
            "reliability": score.reliability_score,
            "consistency": score.consistency_score,
            "response_time": score.response_time_score
        },
        "weights": TrustScorer.WEIGHTS,
        "calculated_at": score.calculated_at
    })


@app.route("/api/v1/trust/score/<did>/vc", methods=["GET"])
def get_score_vc(did):
    """获取W3C可验证凭证格式"""
    records = transactions_db.get(did, [])
    score = scorer.score(did, records)
    vc = scorer.to_w3c_vc(score)
    return jsonify(vc)


@app.route("/api/v1/trust/transaction", methods=["POST"])
def submit_transaction():
    """提交交易记录"""
    data = request.get_json() or {}
    required = ["tx_id", "agent_did", "service", "status"]
    for field in required:
        if field not in data:
            return jsonify({"error": f"Missing field: {field}"}), 400

    record = TransactionRecord(
        tx_id=data["tx_id"],
        agent_did=data["agent_did"],
        service=data["service"],
        status=data["status"],
        response_ms=data.get("response_ms", 0),
        created_at=data.get("created_at", ""),
        amount=data.get("amount", 0)
    )

    if record.agent_did not in transactions_db:
        transactions_db[record.agent_did] = []
    transactions_db[record.agent_did].append(record)

    return jsonify({
        "success": True,
        "message": "Transaction recorded",
        "total_transactions": len(transactions_db[record.agent_did])
    })


@app.route("/api/v1/trust/algorithm", methods=["GET"])
def get_algorithm():
    """获取评分算法说明"""
    return jsonify({
        "algorithm": "AgentTrust Protocol v1.0",
        "weights": TrustScorer.WEIGHTS,
        "description": {
            "completion_rate": "成功交易占比 (35%)",
            "reliability": "100 - 争议*20 - 失败*10 (30%)",
            "consistency": "EWMA指数加权移动平均，30天半衰期 (20%)",
            "response_time": "500ms=100分, 10s=0分, 线性插值 (15%)"
        },
        "grades": {"A+": "95+", "A": "85+", "B+": "75+", "B": "65+", "C+": "55+", "C": "45+", "D": "30+", "F": "<30"},
        "confidence_levels": {"high": "100+ tx", "medium": "25+ tx", "low": "5+ tx", "insufficient": "<5 tx"},
        "source": "github.com/lm203688/agent-trust-protocol"
    })


@app.route("/api/v1/trust/health", methods=["GET"])
def health():
    return jsonify({
        "service": "AgentTrust (AIShield集成版)",
        "status": "healthy",
        "version": "1.0.0",
        "agents_tracked": len(transactions_db)
    })


if __name__ == "__main__":
    print("AgentTrust API服务 (AIShield集成版)")
    print("端点:")
    print("  GET  /api/v1/trust/score/<did>")
    print("  GET  /api/v1/trust/score/<did>/vc")
    print("  POST /api/v1/trust/transaction")
    print("  GET  /api/v1/trust/algorithm")
    print("  GET  /api/v1/trust/health")
    app.run(host="0.0.0.0", port=8467, debug=False)
