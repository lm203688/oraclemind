"""Agent团队统一LLM客户端 — 封装z-ai SDK"""

import json, os, subprocess, time
from typing import Optional, Dict, List

NODE_PATH = "/home/z/.bun/install/global/node_modules"


def call_llm(prompt: str, model: str = "glm-4-plus", max_tokens: int = 2000, temperature: float = 0.7) -> str:
    """单次LLM调用，返回文本"""
    script = f"""
const SDK = require('z-ai-web-dev-sdk').default;
(async () => {{
    const client = await SDK.create();
    const resp = await client.chat.completions.create({{
        model: '{model}',
        messages: [{{role: 'user', content: {json.dumps(prompt)}}}],
        max_tokens: {max_tokens},
        temperature: {temperature}
    }});
    console.log(JSON.stringify({{content: resp.choices[0].message.content, usage: resp.usage}}));
}})().catch(e => console.error(JSON.stringify({{error: e.message}})));
"""
    try:
        result = subprocess.run(
            ["node", "-e", script],
            capture_output=True, text=True, timeout=60,
            env={**os.environ, "NODE_PATH": NODE_PATH}
        )
        data = json.loads(result.stdout.strip())
        if "error" in data:
            return f"[LLM Error: {data['error']}]"
        return data.get("content", "")
    except subprocess.TimeoutExpired:
        return "[LLM Timeout]"
    except Exception as e:
        return f"[LLM Error: {str(e)[:100]}]"


def call_llm_multi(prompt: str, models: List[str] = None, max_tokens: int = 1500) -> Dict[str, str]:
    """多模型串行调用，返回各模型结果"""
    if models is None:
        models = ["glm-4-flash", "glm-4-plus", "agnes"]
    results = {}
    for i, model in enumerate(models):
        results[model] = call_llm(prompt, model=model, max_tokens=max_tokens)
        if i < len(models) - 1:
            time.sleep(1)  # 防429
    return results


def web_search(query: str, count: int = 10) -> List[Dict]:
    """web搜索，返回结果列表"""
    script = f"""
const SDK = require('z-ai-web-dev-sdk').default;
(async () => {{
    const client = await SDK.create();
    const results = await client.functions.invoke('web_search', {{ query: {json.dumps(query)}, count: {count} }});
    console.log(JSON.stringify(results));
}})().catch(e => console.error(JSON.stringify({{error: e.message}})));
"""
    try:
        result = subprocess.run(
            ["node", "-e", script],
            capture_output=True, text=True, timeout=30,
            env={**os.environ, "NODE_PATH": NODE_PATH}
        )
        data = json.loads(result.stdout.strip())
        if isinstance(data, list):
            return data
        if isinstance(data, dict) and "error" in data:
            return [{"error": data["error"]}]
        return [data]
    except Exception as e:
        return [{"error": str(e)[:100]}]


def synthesize(results: Dict[str, str], question: str) -> str:
    """综合多模型结果"""
    if len(results) <= 1:
        return list(results.values())[0] if results else ""
    prompt = f"你是分析综合器。以下是多个AI模型对同一问题的回答，请综合判断，标注共识和分歧，给出最终结论。\n\n问题：{question}\n\n"
    for model, answer in results.items():
        prompt += f"\n## {model}的回答\n{answer[:2000]}\n"
    prompt += "\n## 综合分析:"
    return call_llm(prompt, model="glm-4-plus", max_tokens=1500)
