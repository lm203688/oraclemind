"""
Agent团队统一框架 v1.0
所有Agent继承BaseAgent，遵循统一接口
"""

import os, json, time, sqlite3, traceback
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any


class BaseAgent:
    """Agent基类"""

    def __init__(self, name: str, description: str, port: int):
        self.name = name
        self.description = description
        self.port = port
        self.base_dir = Path(__file__).parent.parent / name
        self.db_path = self.base_dir / "db" / f"{name}.db"
        self.memory_dir = self.base_dir / "project_memory"
        self.growth_log_path = self.base_dir / "growth-log.md"
        self.roadmap_path = self.base_dir / "roadmap.md"

        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self._init_db()
        self._init_growth_log()
        self._init_roadmap()

    def _init_db(self):
        conn = sqlite3.connect(str(self.db_path))
        c = conn.cursor()
        c.executescript("""
            CREATE TABLE IF NOT EXISTS projects (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                profile TEXT,
                status TEXT DEFAULT 'active',
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT,
                decision TEXT,
                reason TEXT,
                outcome TEXT,
                decided_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT,
                task TEXT,
                status TEXT,
                result TEXT,
                completed_at TEXT,
                duration_ms INTEGER
            );
            CREATE TABLE IF NOT EXISTS growth_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT,
                description TEXT,
                lesson TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );
        """)
        conn.commit()
        conn.close()

    def _init_growth_log(self):
        if not self.growth_log_path.exists():
            self.growth_log_path.write_text(f"# {self.name} 成长日志\n\n## 迭代记录\n\n", encoding="utf-8")

    def _init_roadmap(self):
        if not self.roadmap_path.exists():
            self.roadmap_path.write_text(f"# {self.name} 发展路线图\n\n## v1.0 (当前)\n- 基础框架搭建\n\n## v1.1 (计划)\n- 待规划\n", encoding="utf-8")

    def register_project(self, project_id: str, name: str, profile: str = "") -> Dict:
        conn = sqlite3.connect(str(self.db_path))
        c = conn.cursor()
        c.execute("INSERT OR REPLACE INTO projects (id, name, profile, status) VALUES (?, ?, ?, 'active')",
                  (project_id, name, profile))
        conn.commit()
        conn.close()
        # 创建项目记忆目录
        pm = self.memory_dir / project_id
        pm.mkdir(parents=True, exist_ok=True)
        notes = pm / "notes.md"
        if not notes.exists():
            notes.write_text(f"# {name} 项目记忆\n\n", encoding="utf-8")
        return {"status": "ok", "project_id": project_id, "name": name}

    def list_projects(self) -> List[Dict]:
        conn = sqlite3.connect(str(self.db_path))
        c = conn.cursor()
        c.execute("SELECT id, name, profile, status FROM projects ORDER BY created_at DESC")
        rows = c.fetchall()
        conn.close()
        return [{"id": r[0], "name": r[1], "profile": r[2], "status": r[3]} for r in rows]

    def add_decision(self, project_id: str, decision: str, reason: str, outcome: str = "") -> Dict:
        conn = sqlite3.connect(str(self.db_path))
        c = conn.cursor()
        c.execute("INSERT INTO decisions (project_id, decision, reason, outcome) VALUES (?, ?, ?, ?)",
                  (project_id, decision, reason, outcome))
        conn.commit()
        conn.close()
        return {"status": "ok"}

    def add_project_note(self, project_id: str, note: str):
        notes = self.memory_dir / project_id / "notes.md"
        notes.parent.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        with open(notes, "a", encoding="utf-8") as f:
            f.write(f"\n## {ts}\n{note}\n")
        return {"status": "ok"}

    def get_project_context(self, project_id: str) -> Dict:
        conn = sqlite3.connect(str(self.db_path))
        c = conn.cursor()
        c.execute("SELECT name, profile, status FROM projects WHERE id=?", (project_id,))
        row = c.fetchone()
        if not row:
            conn.close()
            return {"error": "project not found"}
        c.execute("SELECT decision, reason, outcome, decided_at FROM decisions WHERE project_id=? ORDER BY decided_at DESC LIMIT 10", (project_id,))
        decisions = [{"decision": d[0], "reason": d[1], "outcome": d[2], "date": d[3]} for d in c.fetchall()]
        c.execute("SELECT task, status, completed_at, duration_ms FROM tasks WHERE project_id=? ORDER BY completed_at DESC LIMIT 10", (project_id,))
        tasks = [{"task": t[0], "status": t[1], "date": t[2], "duration_ms": t[3]} for t in c.fetchall()]
        conn.close()
        notes_path = self.memory_dir / project_id / "notes.md"
        notes = notes_path.read_text(encoding="utf-8") if notes_path.exists() else ""
        return {"project_id": project_id, "name": row[0], "profile": row[1], "status": row[2],
                "recent_decisions": decisions, "recent_tasks": tasks, "notes": notes[:5000]}

    def log_growth(self, event_type: str, description: str, lesson: str = ""):
        conn = sqlite3.connect(str(self.db_path))
        c = conn.cursor()
        c.execute("INSERT INTO growth_log (event_type, description, lesson) VALUES (?, ?, ?)",
                  (event_type, description, lesson))
        conn.commit()
        conn.close()
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        with open(self.growth_log_path, "a", encoding="utf-8") as f:
            f.write(f"\n## {ts} [{event_type}]\n{description}\n")
            if lesson:
                f.write(f"**教训:** {lesson}\n")

    def _log_task(self, project_id: str, task: str, status: str, result: str, duration_ms: int):
        conn = sqlite3.connect(str(self.db_path))
        c = conn.cursor()
        c.execute("INSERT INTO tasks (project_id, task, status, result, completed_at, duration_ms) VALUES (?, ?, ?, ?, ?, ?)",
                  (project_id, task, status, result, datetime.now().isoformat(), duration_ms))
        conn.commit()
        conn.close()

    def health_check(self) -> Dict:
        return {"agent": self.name, "status": "healthy", "port": self.port,
                "db_exists": self.db_path.exists(), "projects_tracked": len(self.list_projects()),
                "timestamp": datetime.now().isoformat()}

    def get_capabilities(self) -> Dict:
        return {"agent": self.name, "description": self.description,
                "capabilities": [], "tools": [], "version": "1.0.0"}

    def execute(self, task: str, params: Dict) -> Dict:
        """子类必须实现"""
        raise NotImplementedError("Subclass must implement execute()")
