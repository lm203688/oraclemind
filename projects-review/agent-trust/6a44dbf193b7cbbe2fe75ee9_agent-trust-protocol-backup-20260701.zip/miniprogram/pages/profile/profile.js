// pages/profile/profile.js
const app = getApp();

Page({
  data: {
    isLoggedIn: false,
    userName: '',
    userId: '',
    agentCount: 0,
    totalTx: 0,
    avgScore: '--',
    menuItems: [
      { icon: '🔗', title: '接入文档', action: 'docs' },
      { icon: '⭐', title: '给我评分', action: 'rate' },
      { icon: '💬', title: '反馈建议', action: 'feedback' },
      { icon: '📖', title: '关于 AgentTrust', action: 'about' },
      { icon: '📦', title: 'npm 包列表', action: 'packages' }
    ]
  },

  onShow() {
    const isLoggedIn = app.globalData.isLoggedIn;
    this.setData({
      isLoggedIn,
      userName: isLoggedIn ? '开发者' : '',
      userId: isLoggedIn ? 'AT-2026-XXXX' : '',
      agentCount: 2,
      totalTx: 37,
      avgScore: 72
    });
  },

  onMenuTap(e) {
    const action = e.currentTarget.dataset.action;
    const actions = {
      docs: () => {
        wx.setClipboardData({
          data: 'https://github.com/lm203688/agent-trust-protocol',
          success: () => wx.showToast({ title: '链接已复制', icon: 'success' })
        });
      },
      rate: () => wx.showToast({ title: '感谢支持！', icon: 'none' }),
      feedback: () => wx.showToast({ title: '反馈邮箱已复制', icon: 'none' }),
      about: () => wx.showModal({
        title: 'AgentTrust',
        content: '开源 AI Agent 信任与支付协议层\nMIT License\nv0.1.0',
        showCancel: false
      }),
      packages: () => wx.showModal({
        title: 'npm 包列表',
        content: 'agent-trust-core\nagent-trust-mcp-server\nagent-trust-x402-listener\nagent-trust-xunhupay',
        showCancel: false
      })
    };
    actions[action] && actions[action]();
  },

  handleLogout() {
    wx.clearStorageSync();
    app.globalData.isLoggedIn = false;
    app.globalData.token = null;
    this.setData({ isLoggedIn: false, userName: '', userId: '' });
    wx.showToast({ title: '已退出', icon: 'none' });
  }
});
