// pages/dashboard/dashboard.js
const app = getApp();

Page({
  data: {
    userName: '',
    overallScore: 0,
    transactionCount: 0,
    confidenceTier: 'insufficient_data',
    rankPercent: '--',
    scoreChange: 0,
    
    dimensions: [
      { key: 'completionRate', name: '完成率', score: 0, color: '#10b981', desc: '成功交易占比' },
      { key: 'responseTime', name: '响应速度', score: 0, color: '#3b82f6', desc: '平均响应时间评分' },
      { key: 'reliabilityScore', name: '可靠性', score: 0, color: '#f59e0b', desc: '争议率倒数' },
      { key: 'consistencyScore', name: '一致性', score: 0, color: '#8b5cf6', desc: '服务质量稳定性' }
    ],
    
    recentTx: [],
    aiInsight: '',
    insightTime: ''
  },

  onLoad() {
    this.loadData();
  },

  onPullDownRefresh() {
    this.loadData(() => {
      wx.stopPullDownRefresh();
    });
  },

  loadData(callback) {
    wx.showLoading({ title: '加载中...' });
    
    // 调用 agent-trust-core API 获取信任分
    // 实际项目中替换为真实 API 地址
    const mockData = {
      overallScore: 72,
      transactionCount: 38,
      confidenceTier: 'medium',
      rankPercent: 15,
      scoreChange: 5,
      dimensions: {
        completionRate: 85,
        responseTime: 68,
        reliabilityScore: 75,
        consistencyScore: 60
      },
      recentTx: [
        { id: '1', peerName: 'Alpha-Agent', amount: 0.05, protocol: 'x402', status: 'success', time: '2 分钟前' },
        { id: '2', peerName: 'Beta-Bot', amount: 0.12, protocol: 'mcp', status: 'success', time: '1 小时前' },
        { id: '3', peerName: 'Gamma-AI', amount: 0.08, protocol: 'a2a', status: 'failure', time: '3 小时前' }
      ],
      aiInsight: '您的完成率很高（85%），但响应速度有提升空间。建议优化 API 超时设置，目标：将平均响应时间从 1200ms 降至 800ms 以内，预计信任分可提升 8-12 分。',
      insightTime: '5 分钟前更新'
    };
    
    // 模拟 API 延迟
    setTimeout(() => {
      this.setData({
        userName: '开发者',
        overallScore: mockData.overallScore,
        transactionCount: mockData.transactionCount,
        confidenceTier: this.formatTier(mockData.confidenceTier),
        rankPercent: mockData.rankPercent,
        scoreChange: mockData.scoreChange,
        dimensions: this.data.dimensions.map(d => ({
          ...d,
          score: mockData.dimensions[d.key] || 0
        })),
        recentTx: mockData.recentTx,
        aiInsight: mockData.aiInsight,
        insightTime: mockData.insightTime
      });
      
      wx.hideLoading();
      callback && callback();
    }, 800);
  },

  formatTier(tier) {
    const map = {
      'insufficient_data': '数据不足',
      'low': '低',
      'medium': '中',
      'high': '高'
    };
    return map[tier] || tier;
  },

  goToTransactions() {
    wx.switchTab({ url: '/pages/transactions/transactions' });
  }
});
