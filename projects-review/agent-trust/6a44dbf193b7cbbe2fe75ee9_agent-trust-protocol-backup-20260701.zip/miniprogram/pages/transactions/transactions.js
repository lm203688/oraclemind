// pages/transactions/transactions.js
Page({
  data: {
    filter: 'all',
    allTx: [],
    filteredTx: []
  },

  onLoad() {
    this.loadTx();
  },

  loadTx() {
    const mockTx = [
      { id: '1', peerName: 'Alpha-Assistant', amount: 0.05, protocol: 'x402', status: 'success', time: '2分钟前' },
      { id: '2', peerName: 'Beta-Bot', amount: 0.12, protocol: 'mcp', status: 'success', time: '1小时前' },
      { id: '3', peerName: 'Gamma-AI', amount: 0.08, protocol: 'a2a', status: 'failure', time: '3小时前' },
      { id: '4', peerName: 'Delta-Agent', amount: 0.15, protocol: 'x402', status: 'success', time: '5小时前' },
      { id: '5', peerName: 'Echo-Bot', amount: 0.03, protocol: 'mcp', status: 'success', time: '8小时前' }
    ];

    this.setData({
      allTx: mockTx,
      filteredTx: mockTx
    });
  },

  setFilter(e) {
    const filter = e.currentTarget.dataset.filter;
    const filtered = filter === 'all' 
      ? this.data.allTx 
      : this.data.allTx.filter(tx => tx.status === filter);

    this.setData({
      filter,
      filteredTx: filtered
    });
  }
});
