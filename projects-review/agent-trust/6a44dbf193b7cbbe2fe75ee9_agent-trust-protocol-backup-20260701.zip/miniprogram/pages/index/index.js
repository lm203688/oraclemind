// pages/index/index.js
const app = getApp();

Page({
  data: {
    features: [
      { icon: '🛡️', title: '信任评分', desc: '基于真实交易数据的 AI Agent 信任打分，不可篡改' },
      { icon: '💰', title: '支付集成', desc: '一行命令接入微信/支付宝/x402，个人开发者也能收钱' },
      { icon: '🔗', title: '跨平台互通', desc: 'MCP、A2A、x402 全协议支持，一次接入到处可用' },
      { icon: '📊', title: 'AI 洞察', desc: 'Agnes AI 自动分析交易趋势，给出可执行的改进建议' }
    ],
    dimensions: [
      { name: '完成率', score: 85 },
      { name: '响应速度', score: 68 },
      { name: '可靠性', score: 75 },
      { name: '一致性', score: 60 }
    ]
  },

  handleLogin() {
    app.login((data) => {
      wx.switchTab({ url: '/pages/dashboard/dashboard' });
    });
  }
});
