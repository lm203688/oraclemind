// pages/agent/agent.js
const app = getApp();

Page({
  data: {
    isLoggedIn: false,
    agentCount: 0,
    totalTx: 0,
    avgScore: '--',
    agents: [],
    showModal: false,
    form: {
      name: '',
      did: '',
      description: '',
      protocols: []
    }
  },

  onLoad() {
    this.checkLogin();
  },

  onShow() {
    if (app.globalData.isLoggedIn) {
      this.loadAgents();
    }
  },

  checkLogin() {
    const isLoggedIn = app.globalData.isLoggedIn;
    this.setData({ isLoggedIn });
    if (isLoggedIn) {
      this.loadAgents();
    }
  },

  loadAgents() {
    // 模拟数据 - 实际项目中调用 API
    const mockAgents = [
      {
        name: 'Alpha-Assistant',
        did: 'did:web:alpha.example.com',
        score: 88,
        status: 'active',
        protocols: ['x402', 'mcp'],
        txCount: 25
      },
      {
        name: 'Beta-Bot',
        did: 'did:web:beta.example.com',
        score: 72,
        status: 'active',
        protocols: ['mcp', 'a2a'],
        txCount: 12
      }
    ];

    const totalTx = mockAgents.reduce((sum, a) => sum + a.txCount, 0);
    const avgScore = mockAgents.length > 0 
      ? Math.round(mockAgents.reduce((sum, a) => sum + a.score, 0) / mockAgents.length)
      : '--';

    this.setData({
      agentCount: mockAgents.length,
      totalTx,
      avgScore,
      agents: mockAgents
    });
  },

  handleLogin() {
    app.login((data) => {
      this.setData({ isLoggedIn: true });
      this.loadAgents();
    });
  },

  showAddModal() {
    this.setData({ showModal: true });
  },

  hideAddModal() {
    this.setData({ 
      showModal: false,
      form: { name: '', did: '', description: '', protocols: [] }
    });
  },

  onInputChange(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({
      [`form.${field}`]: e.detail.value
    });
  },

  toggleProtocol(e) {
    const protocol = e.currentTarget.dataset.protocol;
    let protocols = [...this.data.form.protocols];
    const idx = protocols.indexOf(protocol);
    if (idx >= 0) {
      protocols.splice(idx, 1);
    } else {
      protocols.push(protocol);
    }
    this.setData({ 'form.protocols': protocols });
  },

  submitAgent() {
    const { name, protocols } = this.data.form;
    if (!name) {
      wx.showToast({ title: '请输入 Agent 名称', icon: 'none' });
      return;
    }
    if (protocols.length === 0) {
      wx.showToast({ title: '请选择至少一种协议', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '添加中...' });

    // 模拟 API 调用
    setTimeout(() => {
      const newAgent = {
        name,
        did: this.data.form.did || `did:web:${name.toLowerCase()}.example.com`,
        score: 0,
        status: 'pending',
        protocols,
        txCount: 0
      };

      this.setData({
        agents: [...this.data.agents, newAgent],
        agentCount: this.data.agentCount + 1,
        showModal: false,
        form: { name: '', did: '', description: '', protocols: [] }
      });

      wx.hideLoading();
      wx.showToast({ title: '添加成功', icon: 'success' });
    }, 800);
  },

  goToDetail(e) {
    const did = e.currentTarget.dataset.did;
    wx.navigateTo({ url: `/pages/agent-detail/agent-detail?did=${did}` });
  }
});
