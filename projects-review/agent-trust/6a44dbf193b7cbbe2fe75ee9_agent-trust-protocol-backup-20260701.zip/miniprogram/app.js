// app.js
App({
  onLaunch() {
    // 检查登录状态
    this.checkLogin();
  },

  globalData: {
    userInfo: null,
    isLoggedIn: false,
    apiBase: 'https://api.agent-trust-protocol.com', // 替换为实际 API 地址
  },

  checkLogin() {
    const token = wx.getStorageSync('token');
    if (token) {
      this.globalData.isLoggedIn = true;
      this.globalData.token = token;
    }
  },

  login(callback) {
    wx.showLoading({ title: '登录中...' });
    
    wx.login({
      success: (res) => {
        if (res.code) {
          // 调用后端 API 换取 session
          wx.request({
            url: `${this.globalData.apiBase}/auth/wechat`,
            method: 'POST',
            data: { code: res.code },
            success: (result) => {
              wx.hideLoading();
              if (result.data.token) {
                wx.setStorageSync('token', result.data.token);
                this.globalData.isLoggedIn = true;
                this.globalData.token = result.data.token;
                this.globalData.userInfo = result.data.user;
                callback && callback(result.data);
              }
            },
            fail: () => {
              wx.hideLoading();
              wx.showToast({ title: '登录失败', icon: 'none' });
            }
          });
        }
      }
    });
  }
});
