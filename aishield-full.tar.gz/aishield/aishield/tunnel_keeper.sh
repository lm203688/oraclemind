#!/bin/bash
# AIShield Tunnel Keeper - 自动重启cloudflared
LOG=/home/z/my-project/aishield/tunnel.log
PIDFILE=/home/z/my-project/aishield/tunnel.pid
URLFILE=/home/z/my-project/aishield/tunnel_url.txt

while true; do
    # 杀掉旧的cloudflared
    pkill -f "cloudflared tunnel" 2>/dev/null
    sleep 2
    
    # 启动新的cloudflared
    /tmp/cloudflared tunnel --url http://localhost:8450 --protocol http2 > "$LOG" 2>&1 &
    CF_PID=$!
    echo $CF_PID > "$PIDFILE"
    
    # 等待URL出现
    for i in $(seq 1 30); do
        URL=$(rg "trycloudflare.com" "$LOG" 2>/dev/null | rg "https://" | head -1 | rg -o 'https://[a-z-]+\.trycloudflare\.com')
        if [ -n "$URL" ]; then
            echo "$URL" > "$URLFILE"
            echo "$(date): Tunnel established: $URL (PID: $CF_PID)"
            break
        fi
        sleep 1
    done
    
    # 等待进程退出
    wait $CF_PID 2>/dev/null
    echo "$(date): Tunnel process exited, restarting in 5s..."
    sleep 5
done
