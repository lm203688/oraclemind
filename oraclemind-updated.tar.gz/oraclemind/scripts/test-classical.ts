/**
 * 快速验证5本古籍Agent的核心算法
 */

import { calculateBazi } from '../src/lib/classical/bazi-foundation';
import { runClassicalVerification } from '../src/lib/classical/classical-orchestrator';

async function main() {
  // 测试用例：1990年6月15日14时（庚午年 壬午月 辛亥日 乙未时）
  const chart = calculateBazi(1990, 6, 15, 14);
  console.log('=== 八字排盘 ===');
  console.log(`日主: ${chart.dayMaster} (${chart.dayMasterElement}, ${chart.dayMasterYinYang})`);
  console.log(`四柱: ${chart.year.stem}${chart.year.branch} | ${chart.month.stem}${chart.month.branch} | ${chart.day.stem}${chart.day.branch} | ${chart.hour.stem}${chart.hour.branch}`);
  console.log(`五行统计:`, chart.elementScores);
  console.log(`加权五行:`, chart.weightedScores);
  console.log();

  const result = await runClassicalVerification({
    chart,
    question: '我明年事业运势如何？',
    simulationType: 'personal',
    personalContext: '目前在互联网公司做产品经理，考虑跳槽到创业公司',
  });

  console.log('=== 5本古籍验证结果 ===');
  for (const r of result.reports) {
    console.log(`\n【${r.bookName}】(${r.perspective})`);
    console.log(`  判定: ${r.judgment}`);
    console.log(`  方向分: ${r.directionScore.toFixed(2)} | 置信度: ${r.confidence.toFixed(2)} | 共识: ${r.consensus}`);
    console.log(`  古典建议: ${r.classicalAdvice}`);
    if (r.warnings.length > 0) console.log(`  警告: ${r.warnings.join(' | ')}`);
    if (r.opportunities.length > 0) console.log(`  机会: ${r.opportunities.join(' | ')}`);
  }

  console.log('\n=== 内部分歧分析 ===');
  console.log(`格局派内部一致性: ${result.divergence.patternSchoolConsensus}`);
  console.log(`旺衰vs格局一致性: ${result.divergence.strengthVsPatternConsensus}`);
  console.log(`调候vs其他一致性: ${result.divergence.climateVsOthersConsensus}`);
  console.log(`总体一致性: ${result.divergence.overallConsensus}`);
  console.log(`古典综合方向分: ${result.consensusScore.toFixed(2)}`);
  console.log(`古典综合判定: ${result.consensus}`);
  if (result.divergence.divergencePoints.length > 0) {
    console.log(`分歧点: ${result.divergence.divergencePoints.join('；')}`);
  }
}

main().catch(console.error);
