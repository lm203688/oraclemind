#!/bin/bash
# OracleMind Keep-Alive: 确保 dev server 持续运行
cd /home/z/my-project/oraclemind

while true; do
  # 检查 server 是否在运行
  if ! curl -s -o /dev/null --connect-timeout 2 http://localhost:3000/ 2>/dev/null | grep -q "200"; then
    echo "[$(date '+%H:%M:%S')] Server down, restarting..."
    
    # 杀掉旧进程
    pkill -9 -f "next" 2>/dev/null
    sleep 2
    
    # 检查 node_modules
    if [ ! -f "node_modules/.bin/next" ]; then
      echo "[$(date '+%H:%M:%S')] Reinstalling deps..."
      npm install --silent 2>&1 | tail -1
      npm approve-scripts --all --silent 2>&1 | tail -1
      npx prisma generate --silent 2>&1 | tail -1
    fi
    
    # 启动 dev server
    setsid node_modules/.bin/next dev -H 0.0.0.0 -p 3000 > /tmp/oraclemind-dev.log 2>&1 &
    disown
    
    # 等待就绪
    for i in {1..30}; do
      if curl -s -o /dev/null http://localhost:3000/ 2>/dev/null | grep -q "200"; then
        echo "[$(date '+%H:%M:%S')] Server back up"
        # 预热
        curl -s -o /dev/null http://localhost:3000/ 2>/dev/null
        break
      fi
      sleep 1
    done
  fi
  
  sleep 5
done
