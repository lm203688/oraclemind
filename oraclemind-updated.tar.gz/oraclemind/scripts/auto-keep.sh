#!/bin/bash
# OracleMind 自动恢复 + 保活脚本
# 检测 node_modules 缺失时自动重装，server 挂掉时自动重启

cd /home/z/my-project/oraclemind

while true; do
  # 1. 检查 node_modules
  if [ ! -f "node_modules/.bin/next" ]; then
    echo "[$(date)] node_modules missing, reinstalling..." >> /tmp/auto-keep.log
    npm install --silent 2>&1 | tail -1
    npm approve-scripts --all --silent 2>&1 | tail -1
    npx prisma generate 2>&1 | tail -1
  fi

  # 2. 检查 build 产物
  if [ ! -f ".next/BUILD_ID" ]; then
    echo "[$(date)] Build missing, rebuilding..." >> /tmp/auto-keep.log
    /home/z/my-project/oraclemind/node_modules/.bin/next build 2>&1 | tail -1
  fi

  # 3. 检查 server
  CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 2 http://localhost:3000/ 2>/dev/null)
  if [ "$CODE" != "200" ]; then
    echo "[$(date)] Server down ($CODE), restarting..." >> /tmp/auto-keep.log
    pkill -9 -f "next" 2>/dev/null
    sleep 2
    nohup /home/z/my-project/oraclemind/node_modules/.bin/next start -H 0.0.0.0 -p 3000 >> /tmp/auto-keep.log 2>&1 &
    # 等待就绪
    for i in {1..10}; do
      sleep 3
      curl -s -o /dev/null http://localhost:3000/ 2>/dev/null | grep -q "200" && break
    done
    echo "[$(date)] Server ready" >> /tmp/auto-keep.log
  fi

  sleep 5
done
