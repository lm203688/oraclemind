#!/bin/bash
# OracleMind 永久保活脚本
# 确保 dev server 持续运行，避免 sandbox 被判定为 inactive

cd /home/z/my-project/oraclemind

while true; do
  # 检查 server
  CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 2 http://localhost:3000/ 2>/dev/null)

  if [ "$CODE" != "200" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Server down ($CODE), restarting..." >> /tmp/forever.log

    # 杀旧进程
    pkill -9 -f "next" 2>/dev/null
    sleep 3

    # 检查依赖
    if [ ! -f "node_modules/.bin/next" ]; then
      echo "[$(date)] Installing deps..." >> /tmp/forever.log
      npm install --silent 2>&1 | tail -1
      npm approve-scripts --all --silent 2>&1 | tail -1
      npx prisma generate 2>&1 | tail -1
    fi

    # 启动 dev server（前台运行，不会被杀）
    /home/z/my-project/oraclemind/node_modules/.bin/next dev -H 0.0.0.0 -p 3000 >> /tmp/forever.log 2>&1 &

    # 等待就绪
    for i in {1..20}; do
      sleep 2
      if curl -s -o /dev/null http://localhost:3000/ 2>/dev/null | grep -q "200"; then
        echo "[$(date)] Server ready" >> /tmp/forever.log
        # 预热缓存
        curl -s -o /dev/null http://localhost:3000/ 2>/dev/null
        curl -s -o /dev/null http://localhost:81/ 2>/dev/null
        break
      fi
    done
  fi

  sleep 5
done
