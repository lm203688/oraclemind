#!/bin/bash
# OracleMind 环境快速恢复脚本（Production Standalone 模式）
# 这是最稳定的模式，无 HMR，不会因编译问题崩溃

set -e

PROJECT_DIR="/home/z/my-project/oraclemind"
LOG_FILE="/tmp/oraclemind-prod.log"

echo "=== OracleMind 环境恢复 ==="

# 1. 检查是否已在运行
if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null | grep -q "200"; then
  echo "✓ Server 已在运行 (HTTP 200)"
  if curl -s -o /dev/null -w "%{http_code}" http://localhost:81/ 2>/dev/null | grep -q "200"; then
    echo "✓ Caddy 代理正常"
  fi
  echo "🎉 一切正常！请刷新浏览器"
  exit 0
fi

cd "$PROJECT_DIR"

# 2. 检查 node_modules
if [ ! -f "node_modules/.bin/next" ]; then
  echo "→ node_modules 缺失，重新安装依赖..."
  npm install --silent 2>&1 | tail -3
  npm approve-scripts --all --silent 2>&1 | tail -2
  npx prisma generate --silent 2>&1 | tail -2
  echo "✓ 依赖安装完成"
fi

# 3. 杀掉旧进程
pkill -9 -f "next" 2>/dev/null || true
pkill -9 -f "standalone/server" 2>/dev/null || true
sleep 2

# 4. 检查 build 产物，没有则 build
if [ ! -f ".next/standalone/server.js" ]; then
  echo "→ 执行 production build..."
  node_modules/.bin/next build 2>&1 | tail -5
  echo "✓ Build 完成"
fi

# 5. 复制静态资源到 standalone（build 脚本可能没复制）
if [ -d ".next/static" ] && [ ! -d ".next/standalone/.next/static" ]; then
  cp -r .next/static .next/standalone/.next/ 2>/dev/null || true
fi
if [ -d "public" ] && [ ! -d ".next/standalone/public" ]; then
  cp -r public .next/standalone/ 2>/dev/null || true
fi

# 6. 启动 production standalone server（最稳定）
echo "→ 启动 production standalone server on 0.0.0.0:3000..."
PORT=3000 HOSTNAME=0.0.0.0 setsid node .next/standalone/server.js > "$LOG_FILE" 2>&1 &
disown

# 7. 等待就绪
echo "→ 等待 server 就绪..."
for i in {1..15}; do
  if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null | grep -q "200"; then
    echo "✓ Server 已就绪 (production standalone, port 3000)"
    sleep 1
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:81/ 2>/dev/null | grep -q "200"; then
      echo "✓ Caddy 代理正常 (81 → 3000)"
    fi
    echo ""
    echo "🎉 恢复完成！请刷新浏览器"
    exit 0
  fi
  sleep 1
done

echo "✗ 启动失败"
tail -10 "$LOG_FILE"
exit 1
