#!/bin/bash
# OracleMind Watchdog - 保持 dev server 永远在线
# 每10秒检查一次，如果 server 挂了就自动重启

PROJECT_DIR="/home/z/my-project/oraclemind"
LOG_FILE="/tmp/oraclemind-dev.log"

cd "$PROJECT_DIR"

while true; do
  # 检查 dev server 是否在运行
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 http://localhost:3000/ 2>/dev/null)

  if [ "$HTTP_CODE" != "200" ]; then
    echo "[$(date)] Server down (HTTP $HTTP_CODE), restarting..."
    pkill -9 -f "next" 2>/dev/null
    sleep 2

    # 检查 node_modules
    if [ ! -f "node_modules/.bin/next" ]; then
      echo "[$(date)] node_modules missing, reinstalling..."
      npm install --silent 2>&1 | tail -2
      npm approve-scripts --all --silent 2>&1 | tail -1
      npx prisma generate --silent 2>&1 | tail -1
    fi

    # 重启
    setsid node_modules/.bin/next dev -H 0.0.0.0 -p 3000 > "$LOG_FILE" 2>&1 &
    disown

    # 等待就绪
    for i in {1..30}; do
      if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null | grep -q "200"; then
        echo "[$(date)] Server back up"
        # 预热缓存
        curl -s -o /dev/null http://localhost:3000/ 2>/dev/null
        break
      fi
      sleep 1
    done
  fi

  sleep 10
done
