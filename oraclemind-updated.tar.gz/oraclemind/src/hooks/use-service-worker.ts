'use client';

import { useEffect } from 'react';

/**
 * Service Worker 注册 hook
 * 在客户端挂载时注册 /sw.js，启用 PWA 离线支持
 */
export function useServiceWorker() {
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (!('serviceWorker' in navigator)) return;

    // 生产环境才注册（dev 环境避免缓存干扰）
    if (process.env.NODE_ENV !== 'production') return;

    const register = async () => {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js', {
          scope: '/',
        });
        console.log('[SW] Registered:', registration.scope);
      } catch (err) {
        console.error('[SW] Registration failed:', err);
      }
    };

    register();
  }, []);
}
